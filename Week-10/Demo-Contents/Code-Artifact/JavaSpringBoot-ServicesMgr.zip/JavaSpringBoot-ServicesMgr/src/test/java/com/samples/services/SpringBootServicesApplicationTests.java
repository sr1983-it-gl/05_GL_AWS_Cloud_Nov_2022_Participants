package com.samples.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
